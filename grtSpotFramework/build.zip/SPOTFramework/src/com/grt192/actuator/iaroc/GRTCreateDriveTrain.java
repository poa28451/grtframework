/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.grt192.actuator.iaroc;

import com.grt192.core.Actuator;
import com.grt192.core.Command;
import com.iaroc.irobot.IRobotCreate;

/**
 *
 * @author ajc
 */
public class GRTCreateDriveTrain extends Actuator {

    /**
     * Tankdrive: wheel velocity (-500   500 mm/s)
     */
    public static final int TANKDRIVE = 0;
    public static final int WAITDRIVE = 1;
    public static final int ANGLEDRIVE = 2;
    private int driveMode;
    private IRobotCreate irc;

    public GRTCreateDriveTrain(IRobotCreate irc, int driveMode) {
        this.irc = irc;
        this.driveMode = driveMode;
    }

    public GRTCreateDriveTrain(IRobotCreate irc) {
        this(irc, WAITDRIVE);
    }

//    protected void executeCommand(Command c) throws ActuatorException {
//    }
    protected void executeCommand(Command c) {

        Command c1 = this.dequeue();
//        irc
        switch (driveMode) {
            case TANKDRIVE: {
                if (c1 == null) {
                    c1 = c;
                }
//              driveTrain.tankDrive(c.getValue(), c1.getValue());
                //left.set(c.getValue());
                //right.set(c1.getValue());
                irc.driveDirect((int) c1.getValue(), (int) c.getValue());
                break;
            }
            case WAITDRIVE: {
//                driveTrain.arcadeDrive(c.getValue(), c1.getValue(), false);
                break;
            }
            case 2: {
//                driveTrain.arcadeDrive(c.getValue(), c1.getValue(), true);
                break;
            }
            case 3: {
//                driveTrain.drive(c.getValue(), c1.getValue());
                break;
            }
        }
    }

    protected void halt() {
    }
}
