package com.grt192.deploy;

import com.grt192.core.GRTRobot;
import com.grt192.event.SensorChangeListener;
import com.grt192.event.SensorEvent;
import com.grt192.sensor.GRTCompass;
import com.grt192.sensor.SPOTGyro;
import com.grt192.utils.Util;
import com.sun.spot.io.j2me.radiogram.RadiogramConnection;
import com.sun.spot.resources.Resources;
import com.sun.spot.resources.transducers.IAccelerometer3D;
import com.sun.spot.resources.transducers.ILightSensor;
import com.sun.spot.resources.transducers.ITriColorLED;
import com.sun.spot.sensorboard.EDemoBoard;
import com.sun.spot.sensorboard.peripheral.Servo;
import com.sun.spot.service.BootloaderListenerService;
import com.sun.spot.util.Utils;
import java.io.IOException;
import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;

/**
 * This is a bare version of grtframework + WPI Libraries.
 * @author ajc
 */
public class MainRobot extends GRTRobot implements SensorChangeListener {

    private static final int HOST_PORT = 67;
    private static final int SAMPLE_PERIOD = 100;  // in milliseconds

    public void startRobot() {
        BootloaderListenerService.getInstance().start();
        log("StartRobot");
//        IAccelerometer3D accel = ((IAccelerometer3D) Resources.lookup(IAccelerometer3D.class));

//        GRTCompass c = new GRTCompass(0,50,"Compass");
//        c.addSensorChangeListener(this);
//        c.start();
//        Servo s = new Servo(EDemoBoard.getInstance().getOutputPins()[EDemoBoard.H0]);
//        s.setBounds(1000, 6000);
//        s.setValue(0);
//        s.setValue(2000);

//        while (true) {
//            for (float f = 0; f <= 1; f += .05f) {
//                System.out.println(f);
//                s.setPosition(f);
//                Util.sleep(500);
//            }
//            for (float f = 1; f >= 0; f -= .05f) {
//                System.out.println(f);
//                s.setPosition(f);
//                Util.sleep(500);
//            }
//        }
        testServo();


    }
    
    private void pwm(){
//        EDemoBoard.getInstance().startPul
    }


    private static final int CENTER = 1500;
    private static final int RANGE = 1000;

    private void testServo() {
        EDemoBoard demo = EDemoBoard.getInstance();
        Servo serv0 = new Servo(demo.getOutputPins()[EDemoBoard.H0]);
        Servo serv1 = new Servo(demo.getOutputPins()[EDemoBoard.H1]);
        serv0.setValue(0);
        serv1.setValue(0);
        Utils.sleep(500);

        while (true) {
            for (int i = 0; i < 4; i++) {
                int r = (i % 2 == 0) ? RANGE / 2 : -RANGE / 2;
                serv0.setValue(CENTER + r);
                serv1.setValue(CENTER - r);
                System.out.println("serv0 value: " + serv0.getValue());
                System.out.println("serv1 value: " + serv1.getValue());
                Utils.sleep(2000);
                serv0.setValue(0);
                serv1.setValue(0);
                Utils.sleep(2000);
            }
        }
    }

    private void sendGyroData() {
        SPOTGyro g = new SPOTGyro(1, 2, 50, "gyro");

        g.start();


        RadiogramConnection rCon = null;
        Datagram dg = null;
        String ourAddress = System.getProperty("IEEE_ADDRESS");

        System.out.println("Starting sensor sampler application on " + ourAddress + " ...");

        try {
            rCon = (RadiogramConnection) Connector.open("radiogram://broadcast:" + HOST_PORT);
            dg = rCon.newDatagram(50);
        } catch (Exception e) {
            System.err.println("Caught " + e + " in connection initialization.");
            notifyDestroyed();
        }

        while (true) {
            try {
                long now = System.currentTimeMillis();
                double reading = g.getState("Rate");

                dg.reset();
                dg.writeLong(now);
                dg.writeDouble(reading);
                rCon.send(dg);

                System.out.println("Reading: \t" + reading);

                Utils.sleep(SAMPLE_PERIOD - (System.currentTimeMillis() - now));
            } catch (Exception e) {
                System.err.println("Caught " + e + " while collecting/sending sensor sample.");
            }
        }





//        String s = RadioDataIOStream.open(32).toString();
//        while (true) {
//
//            System.out.println(s);
//            Utils.sleep(1000);
//        }


    }

    public void sensorStateChanged(SensorEvent e, String key) {
        log("" + e.getData().toString() + "\t" + key + "\t " + e.getData(key));
    }
    //        log("new irobot create");
    //        IRobotCreate r = new IRobotCreate();
    //        log("create made!");
    //        r.sensors(IRobotCreateConstants.SENSORS_DISTANCE);
    //        while(true){
    //            log("distance" + r.getAccumulatedDistance());
    //        }
}
