/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.grt192.mechanism.iaroc;

import com.grt192.core.Mechanism;
import com.grt192.sensor.iaroc.GRTCreateBeaconSensor;
import com.grt192.sensor.iaroc.GRTCreateBumpSensor;
import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateSerialConnection;
import com.sun.spot.resources.transducers.IIOPin;
import com.sun.spot.sensorboard.EDemoBoard;

/**
 *
 * @author ajc
 */
public class IRCreate extends Mechanism {

    private IRobotCreate create;

    public IRCreate(IRobotCreate irc) {
        this.create = irc;
        addActuators();
        addSensors();
    }

    /**
     * Notes about pins:
     * d0: uart rx
     * d1: uart tx
     * d2: i2c sda(data)
     * d3: i2c scl(clock
     * d4: baud rate
     *
     * create side:
     * 1:rx
     * 2:tx
     * 14: gnd
     * 15: baud rate
     *
     */
    public static IRCreate getDefault() {
        EDemoBoard spotboard = EDemoBoard.getInstance();
        IIOPin baudrate = EDemoBoard.getInstance().getIOPins()[EDemoBoard.D4];

        IRobotCreateSerialConnection ircsc = new IRobotCreateSerialConnection(spotboard, baudrate, false);
        IRobotCreate irc = new IRobotCreate(ircsc, false, true, true);
        return new IRCreate(irc);
    }

    private void addActuators() {
    }

    private void addSensors() {

        //create sensors
        addSensor("beacon", new GRTCreateBeaconSensor(create));
        getSensor("beacon").start();
        addSensor("bump", new GRTCreateBumpSensor(create));
        getSensor("bump").start();

        
    }

}
