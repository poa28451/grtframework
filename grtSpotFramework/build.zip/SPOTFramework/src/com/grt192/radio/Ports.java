
package com.grt192.radio;

/**
 *
 * @author ajc
 */
public interface Ports {

    public static final int BROADCAST_PORT = 42;
}
