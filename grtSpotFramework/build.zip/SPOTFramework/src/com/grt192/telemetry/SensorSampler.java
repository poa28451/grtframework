/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.grt192.telemetry;

import com.grt192.core.GRTObject;
import com.sun.spot.io.j2me.radiogram.RadiogramConnection;
import com.sun.spot.resources.transducers.ITransducer;
import java.io.IOException;
import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;

/**
 *
 * @author ajc
 */
public class SensorSampler extends GRTObject {

    private static final int HOST_PORT = 67;//TODO have a com.grt192.radio.ports class/interface?
    private static RadiogramConnection rCon = null;
    private static Datagram dg = null;
    private String service;
    private boolean running = false;

    public SensorSampler(String service, ITransducer t) {
        this.service = service;
        init();
    }

    private static void init() {
        try {
            // Open up a broadcast connection to the host port
            // where the 'on Desktop' portion of this demo is listening
            rCon = (RadiogramConnection) Connector.open("radiogram://broadcast:" + HOST_PORT);
            dg = rCon.newDatagram(rCon.getMaximumLength());  // only sending 12 bytes of data
        } catch (Exception e) {
            System.err.println("Caught " + e + " in connection initialization.");
        }
    }

    public void sendData(double reading) {
        sendData(reading, service);
    }

    public static void sendData(double reading, String service) {
        sendData(reading, service, System.currentTimeMillis());
    }

    public static void sendData(double reading, String service, long time) {
        if (dg == null) {
            init();
        }
        try {
            dg.reset();
            dg.writeLong(time);
            dg.writeDouble(reading);
            dg.writeUTF(service);
            rCon.send(dg);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void run() {
        running = true;
        while (running) {
        }
    }
}
