package com.grt192.event.controller;

public interface PIDListener {

	public void onSetpointReached(PIDEvent e);
}
