
package com.grt192.event.component.iaroc;

import com.grt192.sensor.iaroc.GRTCreateBumpSensor;

/**
 * Event handling: no separate events per sensor, but
 * @author ajc
 */
public interface BumpListener {

    public void bump(BumpEvent e);
}
