/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.grt192.event.component;

/**
 *
 * @author student
 */
public interface XboxJoystickListener {
    public void leftXAxisMoved(XboxJoystickEvent e);
    public void leftYAxisMoved(XboxJoystickEvent e);
    public void leftZAxisMoved(XboxJoystickEvent e);

    public void rightXAxisMoved(XboxJoystickEvent e);
    public void rightYAxisMoved(XboxJoystickEvent e);

    public void throttleMoved(XboxJoystickEvent e);

    public void triggerMoved(XboxJoystickEvent e);
}
