package com.grt192.event;

/**
 *
 * @author anand
 */
public interface GlobalListener {

    public void globalChanged(GlobalEvent e);
}
