/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.grt192.sensor.component;

/**
 *
 * @author ajc
 */
public class AccumulatorResult {
    /**
     * The total value accumulated
     */
    public long value;
    /**
     * The number of sample vaule was accumulated over
     */
    public long count;


}
