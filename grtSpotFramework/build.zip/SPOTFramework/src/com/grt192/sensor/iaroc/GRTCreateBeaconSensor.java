/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.grt192.sensor.iaroc;

import com.grt192.core.Sensor;
import com.grt192.event.component.iaroc.BeaconListener;
import com.iaroc.irobot.IRobotCreate;
import com.iaroc.irobot.IRobotCreateConstants;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 *
 * @author ajc
 */
public class GRTCreateBeaconSensor extends Sensor {

    private IRobotCreate irc;
    private Vector beaconListeners;

    public GRTCreateBeaconSensor(IRobotCreate irc) {
        this.irc = irc;
        beaconListeners = new Vector();
    }

    public void poll() {
        irc.sensors(IRobotCreateConstants.SENSORS_GROUP_ID6, null);
        Hashtable prev = getState();
        setState("RedBUOY", FALSE);
        setState("GreenBUOY", FALSE);
        setState("ForceField", FALSE);

        int rawByte = irc.getInfraredByte(); //Refer to IRobotCreateConstants.java
        switch (rawByte) {
            case IRobotCreateConstants.INFRARED_BYTE_NONE:
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_FORCE_FIELD:
                setState("ForceField", TRUE);
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_RED_BUOY:
                setState("RedBUOY", TRUE);
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_GREEN_BUOY:
                setState("GreenBUOY", TRUE);
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_RED_GREEN_BUOY_FORCE_FIELD:
                setState("RedBUOY", TRUE);
                setState("GreenBUOY", TRUE);
                setState("ForceField", TRUE);
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_GREEN_BUOY_FORCE_FIELD:
                setState("GreenBUOY", FALSE);
                setState("ForceField", FALSE);
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_RED_BUOY_FORCE_FIELD:
                setState("RedBUOY", TRUE);
                setState("ForceField", TRUE);
                break;
            case IRobotCreateConstants.INFRARED_BYTE_HOME_BASE_RED_GREEN_BUOY:
                setState("RedBUOY", TRUE);
                setState("GreenBUOY", TRUE);
                break;
        }
        if(stateChanged(prev)){
            notifyBeaconListeners();
        }

    }
    
    public void notifyBeaconListeners(){
        for(int i = 0; i<beaconListeners.size(); i++){
            ((BeaconListener)beaconListeners.elementAt(i)).beaconSensorStateChange(this);
        }
    }

    public void addBeaconListener(BeaconListener l) {
        beaconListeners.addElement(l);
    }

    public void removeBeaconListener(BeaconListener l) {
        beaconListeners.removeElement(l);
    }

    private boolean stateChanged(Hashtable prev) {
        Enumeration keys = prev.keys();
        while (keys.hasMoreElements()) {
            String key = (String) keys.nextElement();
            if (!prev.get(key).equals(getState().get(key))) {
                return true;
            }
        }
        return false;
    }
}
