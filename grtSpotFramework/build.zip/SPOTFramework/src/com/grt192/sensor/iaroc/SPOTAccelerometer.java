/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.grt192.sensor.iaroc;

import com.grt192.core.Sensor;
import com.sun.spot.resources.transducers.IAccelerometer3D;

/**
 *
 * @author ajc
 */
public class SPOTAccelerometer extends Sensor {

    private IAccelerometer3D accelerometer;

    public SPOTAccelerometer() {
    }

    public void poll() {
    }
}
